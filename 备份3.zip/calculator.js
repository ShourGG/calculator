class Calculator {
  constructor() {
    if (!window.calculator) {
      throw new Error('window.calculator not initialized');
    }
    
    this.calculator = window.calculator;
    
    // 确保转换器组件存在
    if (!this.calculator.converter || !this.calculator.currency) {
      throw new Error('Required calculator components not initialized');
    }
    
    this.converter = this.calculator.converter;
    this.currency = this.calculator.currency;
    
    // 确保只初始化一次
    if (window.calculatorInstance) {
      return window.calculatorInstance;
    }
    window.calculatorInstance = this;
    
    this.history = JSON.parse(localStorage.getItem('calculatorHistory') || '[]');
    
    // 先获取所有需要的DOM元素
    this.initializeElements();
    // 初始化按钮
    this.initializeButtons();
    // 绑定所有事件（包括历史记录按钮）
    this.bindEvents();
    // 最后加载默认模式
    this.loadLastMode();
  }

  initializeElements() {
    this.display = document.getElementById('display');
    this.buttons = document.getElementById('buttons');
    this.calculatorContainer = document.getElementById('calculatorContainer');
    // 添加历史按钮和容器的引用
    this.historyBtn = document.querySelector('.history-btn');
    this.calculatorWrapper = document.querySelector('.calculator-container');
  }

  initializeButtons() {
    const buttons = [
      ['C', '←', '%', '/'],
      ['7', '8', '9', '*'],
      ['4', '5', '6', '-'],
      ['1', '2', '3', '+'],
      ['00', '0', '.', '=']
    ];

    this.buttons.innerHTML = buttons
      .map(row => row
        .map(btn => `<button data-value="${btn}">${btn}</button>`)
        .join('')
      )
      .join('');
  }

  bindEvents() {
    // 数字按钮事件 - 使用事件委托
    this.buttons.removeEventListener('click', this.handleButtonsClick);  // 先移除可能存在的事件监听
    this.handleButtonsClick = (e) => {
      if (e.target.tagName === 'BUTTON') {
        this.handleButtonClick(e.target.dataset.value);
      }
    };
    this.buttons.addEventListener('click', this.handleButtonsClick);

    // 键盘事件
    document.removeEventListener('keydown', this.handleKeyDown);  // 先移除可能存在的事件监听
    this.handleKeyDown = (e) => {
      const key = e.key;
      if (/[\d+\-*/.%]|Enter|Backspace|Delete|=/.test(key)) {
        e.preventDefault();
        let value = key;
        if (key === 'Enter' || key === '=') value = '=';
        if (key === 'Backspace' || key === 'Delete') value = '←';
        this.handleButtonClick(value);
      }
    };
    document.addEventListener('keydown', this.handleKeyDown);

    // 标签页切换事件
    document.querySelectorAll('.tab-item').forEach((tab, index) => {
      tab.addEventListener('click', () => {
        this.handleTabChange(index);
      });
    });

    // 图标点击事件
    document.querySelectorAll('.icon-item').forEach(icon => {
      icon.addEventListener('click', () => {
        this.switchMode(icon.dataset.mode);
      });
    });

    // 历史记录按钮事件
    if (this.historyBtn) {
      this.historyBtn.removeEventListener('click', this.handleHistoryClick);  // 先移除可能存在的事件监听
      this.historyBtn.addEventListener('click', this.handleHistoryClick.bind(this));
    }

    // 初始渲染历史记录
    this.renderHistory();
  }

  handleHistoryClick(e) {
    e.stopPropagation();
    this.calculatorWrapper.classList.toggle('history-active');
  }

  renderHistory() {
    const historyList = document.querySelector('.history-list');
    historyList.innerHTML = this.history
      .map(item => `
        <div class="history-item">
          <div class="history-expression">${item.expression}</div>
          <div class="history-result">${item.result}</div>
        </div>
      `)
      .join('');
  }

  handleButtonClick(value) {
    switch(value) {
      case 'C':
        this.display.value = '';
        break;
      case '←':
        this.display.value = this.display.value.slice(0, -1);
        break;
      case '=':
        try {
          const expression = this.display.value;
          const result = window.calculator.calculate(expression);
          this.display.value = result;
          
          // 添加到历史记录
          this.history.unshift({
            expression: expression,
            result: result
          });
          
          // 限制历史记录数量
          if (this.history.length > 50) {
            this.history.pop();
          }
          
          // 保存到本地存储
          localStorage.setItem('calculatorHistory', JSON.stringify(this.history));
          
          // 更新历史记录显示
          this.renderHistory();
        } catch(e) {
          this.display.value = 'Error';
        }
        break;
      case '%':
        try {
          const currentValue = parseFloat(this.display.value);
          this.display.value = currentValue / 100;
        } catch(e) {
          this.display.value = 'Error';
        }
        break;
      default:
        this.display.value += value;
    }
  }

  loadLastMode() {
    // 默认显示计算器
    document.querySelector('.tab-item').click();
  }

  switchMode(mode) {
    // 隐藏所有容器
    document.querySelectorAll('.converter-container').forEach(container => {
      container.classList.remove('active');
    });
    
    // 隐藏计算器容器和图标区域
    this.calculatorContainer.style.display = 'none';
    document.querySelector('.converter-icons').style.display = 'none';

    // 显示选中的容器
    switch (mode) {
      case 'calculator':
        this.calculatorContainer.style.display = 'block';
        break;
      case 'currency':
        document.getElementById('currencyContainer').classList.add('active');
        break;
      case 'length':
        document.getElementById('lengthContainer').classList.add('active');
        break;
      case 'weight':
        document.getElementById('weightContainer').classList.add('active');
        break;
      case 'area':
        document.getElementById('areaContainer').classList.add('active');
        break;
    }
  }

  handleTabChange(index) {
    // 移除所有 active 类
    document.querySelectorAll('.tab-item').forEach(t => t.classList.remove('active'));
    // 添加 active 类到当前标签
    document.querySelectorAll('.tab-item')[index].classList.add('active');
    
    // 获取所有需要切换的元素
    const converterIcons = document.querySelector('.converter-icons');
    const calculatorContainer = document.getElementById('calculatorContainer');
    const converterContainers = document.querySelectorAll('.converter-container');
    
    // 关闭历史面板
    this.calculatorWrapper.classList.remove('history-active');

    if (index === 0) { // 切换到计算器
      // 先隐藏转换器
      converterIcons.classList.add('hide');
      // 隐藏所有转换器界面
      converterContainers.forEach(container => {
        container.classList.remove('active');
      });
      
      // 延迟显示计算器
      setTimeout(() => {
        calculatorContainer.style.display = 'block';
        converterIcons.style.display = 'none';
        // 移除隐藏类触发动画
        setTimeout(() => calculatorContainer.classList.remove('hide'), 50);
      }, 300);
    } else { // 切换到换算
      // 先隐藏计算器
      calculatorContainer.classList.add('hide');
      // 隐藏所有转换器界面
      converterContainers.forEach(container => {
        container.classList.remove('active');
      });
      
      // 延迟显示转换器图标
      setTimeout(() => {
        converterIcons.style.display = 'grid';
        calculatorContainer.style.display = 'none';
        // 移除隐藏类触发动画
        setTimeout(() => converterIcons.classList.remove('hide'), 50);
      }, 300);
    }
  }
}

// 初始化计算器
if (!window.calculator) {
  document.addEventListener('DOMContentLoaded', () => {
    new Calculator();
  });
} 