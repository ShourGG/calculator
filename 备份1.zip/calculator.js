class Calculator {
  constructor() {
    if (!window.calculator) {
      throw new Error('window.calculator not initialized');
    }
    
    this.calculator = window.calculator;
    
    // 确保转换器组件存在
    if (!this.calculator.converter || !this.calculator.currency) {
      throw new Error('Required calculator components not initialized');
    }
    
    this.converter = this.calculator.converter;
    this.currency = this.calculator.currency;
    
    this.initializeElements();
    this.initializeButtons();
    this.loadLastMode();
    this.bindEvents();
  }

  initializeElements() {
    this.display = document.getElementById('display');
    this.buttons = document.getElementById('buttons');
    this.modeSelect = document.getElementById('mode');
    this.calculatorContainer = document.getElementById('calculatorContainer');
  }

  initializeButtons() {
    const buttons = [
      ['C', '←', '%', '/'],
      ['7', '8', '9', '*'],
      ['4', '5', '6', '-'],
      ['1', '2', '3', '+'],
      ['00', '0', '.', '=']
    ];

    this.buttons.innerHTML = buttons
      .map(row => row
        .map(btn => `<button data-value="${btn}">${btn}</button>`)
        .join('')
      )
      .join('');
  }

  bindEvents() {
    this.buttons.addEventListener('click', (e) => {
      if (e.target.tagName === 'BUTTON') {
        this.handleButtonClick(e.target.dataset.value);
      }
    });

    document.addEventListener('keydown', (e) => {
      const key = e.key;
      if (/[\d+\-*/.%]|Enter|Backspace|Delete|=/.test(key)) {
        e.preventDefault();
        let value = key;
        if (key === 'Enter' || key === '=') value = '=';
        if (key === 'Backspace' || key === 'Delete') value = '←';
        this.handleButtonClick(value);
      }
    });

    // 添加模式切换事件
    this.modeSelect.addEventListener('change', () => {
      this.switchMode(this.modeSelect.value);
    });
  }

  handleButtonClick(value) {
    switch(value) {
      case 'C':
        this.display.value = '';
        break;
      case '←':
        this.display.value = this.display.value.slice(0, -1);
        break;
      case '=':
        try {
          this.display.value = window.calculator.calculate(this.display.value);
        } catch(e) {
          this.display.value = 'Error';
        }
        break;
      case '%':
        try {
          const currentValue = parseFloat(this.display.value);
          this.display.value = currentValue / 100;
        } catch(e) {
          this.display.value = 'Error';
        }
        break;
      default:
        this.display.value += value;
    }
  }

  loadLastMode() {
    const lastMode = localStorage.getItem('lastCalculatorMode');
    if (lastMode) {
      this.modeSelect.value = lastMode;
      this.switchMode(lastMode);
    } else {
      // 默认显示计算器
      this.modeSelect.value = 'calculator';
      this.switchMode('calculator');
    }
  }

  switchMode(mode) {
    // 隐藏所有容器
    document.querySelectorAll('.converter-container').forEach(container => {
      container.classList.remove('active');
    });
    
    // 隐藏计算器容器
    this.calculatorContainer.classList.remove('active');

    // 保存最后使用的模式
    localStorage.setItem('lastCalculatorMode', mode);

    // 显示选中的容器
    switch (mode) {
      case 'calculator':
        this.calculatorContainer.classList.add('active');
        break;
      case 'currency':
        document.getElementById('currencyContainer').classList.add('active');
        break;
      case 'length':
        document.getElementById('lengthContainer').classList.add('active');
        break;
      case 'weight':
        document.getElementById('weightContainer').classList.add('active');
        break;
      case 'area':
        document.getElementById('areaContainer').classList.add('active');
        break;
    }
  }
}

// 初始化计算器
document.addEventListener('DOMContentLoaded', () => {
  new Calculator();
}); 